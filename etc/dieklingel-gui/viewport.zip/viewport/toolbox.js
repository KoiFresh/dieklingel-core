var toolbox = {
    getUrlParameter: function(sParam) {
        var sPageURL = decodeURIComponent(window.location.search.substring(1)),
            sURLVariables = sPageURL.split('&'),
            sParameterName;
    
        var result = undefined;
    
        for(var i = 0; i < sURLVariables.length; i++) {
            sParameterName = sURLVariables[i].split('=');
            if (sParameterName[0] === sParam) {
                result = sParameterName[1] === undefined ? undefined : sParameterName[1];
            }
        }
        return result;
    },
}
export default toolbox;