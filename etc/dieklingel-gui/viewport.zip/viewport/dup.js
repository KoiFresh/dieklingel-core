class core {
    constructor(domain) {
        this.connect(domain);
    }

    connect(domain) { 
        this.domain = domain;
        this.websocket = new WebSocket(domain);
        this.websocket.onopen = () => {
            console.log("core connected");
        };
        this.websocket.onmessage = (message) => {
            var json = JSON.parse(message.data);
            //this.dispatchEvent(new Event("unlock"));
    
            $(this).trigger(json.Body.Context);
            /*try {
                
                console.log("message", json["body"]["context"]);
            } catch(e) {
                console.log("received message has the wrong format! or ", e.message);
            } */
        }
        this.websocket.onerror = () => {
            this.websocket.close();
        }
        this.websocket.onclose = () => {
            console.log("core disconnected");
            setTimeout(() => {
                this.connect(this.domain);
            }, 5000);   
        }
    }

    send(message) {
        if(this.websocket !== null && this.websocket.readyState === WebSocket.OPEN) {
            this.websocket.send(message);
        } 
    }
}
    
var Context = {
    Response: 'response',
    DeviceUpdate: 'device-update',
    ConnectionState: 'connection-state',
    Movement: 'movement',
    DisplayState: 'display-state',
    Log: 'log',
    Unlock: 'unlock',
    EnterPasscode: 'enter-passcode',
    Call: 'call',
    Register: 'register',
    Script: 'script',
    Unknown: 'unknown'
}

export {core, Context};
