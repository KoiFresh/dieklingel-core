class xView extends HTMLElement {
    timeout = undefined;
    visible = true;

    constructor() {
        super();
    }

    connectedCallback() {
        //$(this).load($(this).attr("content"));
        $(this).css("background-color", this.attribute("color","#000000"));
        $(this).css("position", "absolute");
        $(this).css("width", this.attribute("width", "100vw"));
        $(this).css("height",this.attribute("height", "100vh"));
        //$(this).css("top", this.attribute("x", "0"));
        //$(this).css("left", this.attribute("y", "0"));
        //$(this).load("/ressources/screensaver.html");
        this.r = this.attachShadow({mode: 'open'});
        //$(this).click(this.hide);
        this.draw();
    }

    attributeChangedCallback(attrName, oldVal, newVal) {
        this.draw();
    }

    draw() {
        var src = this.attribute("content", "");
        if(src !== "") {
            $(this.r).load(src);
        }
    }

    show() {
        $(this).css("display", "block");
        if(!this.visible) {
            eval(this.attribute("onshow", "() => {}"))();
            this.visible = true;
        }
    }    

    hide() {
        $(this).css("display", "none");
        if(this.visible) {
            eval(this.attribute("onhide", "() => {}"))();
            this.visible = false;
        }
        
        let timeout = $(this).attr("timeout");
        clearTimeout(this.timeout);
        if(timeout > 0) {
            this.timeout = setTimeout(() => {
                this.show();
            }, timeout);
        }
    }

    attribute(name, value) {
        let attr = $(this).attr(name);
        if(typeof attr === 'undefined' || attr === false) 
        {
            attr = value;
        }
        return attr;
    }
}
customElements.define('x-view', xView);