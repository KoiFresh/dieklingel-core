class xPage extends HTMLIFrameElement {
    constructor() {
        super();
    }

    connectedCallback() {
        $(this).on("load", (event) => {
            this.resize();            

            $(this.contentWindow.document).ready(() => {
                $(this.contentWindow.document).on("touchstart",() => {
                    window.top.postMessage({"event":"touchstart", "sender": this.contentWindow.document.title }, "*");
                });
            });
        });

        this.style.border = "none";
        this.style.outline = "none";
        this.style.boxSizing = "border-box";
        this.style.display = "block";
        this.style.maxWidth = "100vw";
        this.style.maxHeight = "100vh";
        this.style.overflow = "hidden";
        //this.style.pointerEvents = "none";
    }

    resize() {
        //console.log(this.contentWindow.document.body.offsetHeight + "px");
        //this.style.height = // this.contentWindow.document.body.offsetHeight + "px";
        this.style.width  = "100vw"; //= this.contentWindow.document.body.offsetWidth + "px";
        this.style.height = this.contentWindow.document.body.offsetHeight + "px";
    }
}
customElements.define('x-page', xPage, {extends: 'iframe'});