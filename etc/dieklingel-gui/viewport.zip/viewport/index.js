import toolbox from "./toolbox.js";
import * as dup from "./dup.js";

var viewport = {
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
    resize: function() {
        $('#viewport').css('top', viewport.top + "px");
        $('#viewport').css('left', viewport.left + "px");
        $('#viewport').css('width',  ( $(window).width() - viewport.right - viewport.left) + "px");
        $('#viewport').css('height', ( $(window).height() - viewport.bottom - viewport.top) + "px");
    },
}

$(document).ready(() => {
    viewport.top = toolbox.getUrlParameter("t") ?? viewport.top;
    viewport.bottom = toolbox.getUrlParameter("b") ?? viewport.bottom;
    viewport.left = toolbox.getUrlParameter("l") ?? viewport.left;
    viewport.right = toolbox.getUrlParameter("r") ?? viewport.right;
    viewport.resize();
    $("#viewport").on("load", () => {
        console.log("[viewport] interface loaded");
    });
    $("#viewport").attr("src", "/interface/");
});

$(window).resize(() => {
    viewport.resize();
});